import java.io.*;
import java.io.File;
import java.io.IOException;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;


public class initializare extends CitireTastatura {
	
	int width;
	int height;  	   	
   	public initializare() {
		// TODO Auto-generated constructor stub
   		super();
   		}
   	
	public initializare(File f, BufferedImage image) {
		// TODO Auto-generated constructor stub
   		super(f,image);
	}
	
	public int getWidth()
	{
		return this.image.getWidth();		
	}
	
	public int getHeight()
	{
		return this.image.getHeight();		
	}
	
	public void setWidth()
	{
		this.width = this.image.getWidth();		
	}
	
	public void setHeight()
	{
		this.height = this.image.getHeight();		}
	
	
	public BufferedImage prelucrareImagine(BufferedImage  image, int c,int width,int height) {
		
		for (int x = 0; x < width; x++) {													
			for (int y = 0; y < height; y++) {
				int gray = image.getRGB(x, y) & 0xff;
				gray =(int) (c * ((Math.log(gray + 1))/Math.log(2)));
				image.setRGB(x, y, ((gray * 256) + gray) * 256 + gray);
			}
		} 		  
		return image;
		}

	public void saveImage() {
		caleFisierFinal();
		setImagineFinala();
	}

	
}
