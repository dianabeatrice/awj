import java.io.*;
import java.util.Scanner;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;


public abstract class CitireTastatura {
	
	File f;
	File output;
	BufferedImage image;
	int c; 
	
	
	public CitireTastatura () {
		
		 citesteC();
		 citesteCaleFisier();
		 setImagine();
		
	}
	public CitireTastatura (File f,BufferedImage image) {
		
		 this.c = 0;
		 citesteCaleFisier();
		 setImagine();
		
	}
	
	public void setFisier(String cale) { //aici vom citi de la tastura path-ul pozei pe care o sa o editam
		this.f = new File(cale);
		
	}
	
	public File getFisier() {
		return f;
	}
	
	public void citesteCaleFisier() {
		System.out.println("Introduceti calea fisierului: ");
		Scanner in = new Scanner(System.in);
		String cale = in.nextLine();
			    
	    setFisier(cale);	    
	}
	
	public void setImagine() {
		
		try{
		      this.image = ImageIO.read(this.f);
		      System.out.println("Reading complete// S-a citit si gasit imaginea.");
		    }catch(IOException e){
		      System.out.println("Error: "+e);
		    }
	}
	
	public int getC() {		 
	    return c;		
	}
	
	public void setC(int c) {
		this.c = c;
	}	
	
	public void citesteC() {
		System.out.print("introdu nivelul c de transormare \n c = ");
		Scanner in = new Scanner(System.in);
		c = in.nextInt();
	    	    
	    setC(c);	    
	}
	
	public void caleFisierFinal() {
		System.out.println("Introduceti calea fisierului prelucrat: ");//D:\weloveit\Output2.jpg
		Scanner intrare = new Scanner(System.in);
		String cale = null;
		cale = intrare.nextLine();
		    
	    setCaleFisierFinal(cale);	    
	}
	
	public void setCaleFisierFinal(String cale) { // path-ul pozei noi									
		this.output = new File(cale);
	}
	
	public void setImagineFinala() {
		try{
			  ImageIO.write(this.image, "bmp", this.output);
		      System.out.println("S-a salvat imaginea finala.");
		    }catch(IOException e){
		      System.out.println("Error: "+e);
		    }
	}
	
}
