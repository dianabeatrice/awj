import java.io.*;
import java.io.File;
import java.io.IOException;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;

public class Main  {
	
	public static void main(String[] args){
	
		long startTime = System.nanoTime();
		
		initializare pozaInitiala = new initializare();
			
		pozaInitiala.width = pozaInitiala.getWidth();
		pozaInitiala.height = pozaInitiala.getHeight();
		
		pozaInitiala.image = pozaInitiala.prelucrareImagine(pozaInitiala.image,pozaInitiala.c,pozaInitiala.width,pozaInitiala.height);
		pozaInitiala.saveImage();
		
		long estimatedTime = System.nanoTime() - startTime;
		System.out.println("\nTimp modificare imagine: "+ estimatedTime/Math.pow(10, 9) + "s");
			
	}	

}
