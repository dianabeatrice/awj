import java.io.*;
import java.io.File;
import java.io.IOException;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;


public abstract class CitireImagine{
	File f;
	BufferedImage image;
	
	public CitireImagine (File f,BufferedImage image){
		
		setFisier(f);
		setImagine(image);
	}

	public CitireImagine (){
		setFisier();
		setImagine();
	}
	
	public File setFisier(File f) {
		f = new File("D:\\weloveit\\tricou.jpg");
		return f;
	}
	public File setFisier() {
		f = null;
		return f;
	}
	
	public BufferedImage setImagine(BufferedImage image) {
		try{
		      image = ImageIO.read(f);
		      System.out.println("Reading complete.");
		    }catch(IOException e){
		      System.out.println("Error: "+e);
		    }
		return image;
	}
	public BufferedImage setImagine() {
		image = null;
		return image;
	}
	public File getFisier() {
		return f;
	}
		
	public void getStare() {
		System.out.println("fisierul este " + getFisier());
	}
}
